﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlooringModels.Responses;

namespace FlooringModels.Interfaces
{
    public interface IAdd
    {
        OrderAddResponse Add(string state, string productType, DateTime date, string name, decimal area);
    }
}

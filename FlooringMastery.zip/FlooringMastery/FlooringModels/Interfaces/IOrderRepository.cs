﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlooringModels.Interfaces
{
    public interface IOrderRepository
    {
        List<Order> LoadOrders(DateTime orderDate);
        void SaveOrder(Order order);
        void UpdateList(Order order);
        void Delete(Order order);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using FlooringModels;
using System.Data.SqlClient;

namespace FlooringDAL
{
    public class ProductRepository
    {
        public List<Product> LoadProducts()
        {
            List<Product> products = new List<Product>();

            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = "Server=localhost;Database=FlooringMastery;Trusted_Connection=true";
                connection.Open();
                SqlCommand command = new SqlCommand("select * from Product", connection);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while(reader.Read())
                    {
                        Product newProduct = new Product();
                        newProduct.ProductType = reader[0].ToString();
                        newProduct.CostPerSquareFoot = decimal.Parse(reader[1].ToString());
                        newProduct.LaborCostPerSquareFoot = decimal.Parse(reader[2].ToString());

                        products.Add(newProduct);
                    }
                    connection.Close();
                    connection.Dispose();
                    return products;
                }
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using FlooringModels;
using System.Data.SqlClient;

namespace FlooringDAL
{
    public class StateRepository
    {
        public List<State> LoadStates()
        {
            List<State> states = new List<State>();

            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = "Server=localhost;Database=FlooringMastery;Trusted_Connection=true";
                connection.Open();
                SqlCommand command = new SqlCommand("select * from Tax", connection);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        State newState = new State();
                        newState.StateCode = reader[0].ToString();
                        newState.StateName = reader[1].ToString();
                        newState.TaxRate = decimal.Parse(reader[2].ToString());

                        states.Add(newState);
                    }
                    connection.Close();
                    connection.Dispose();
                    return states;
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlooringModels;
using FlooringModels.Interfaces;
using System.IO;
using System.Data.SqlClient;

namespace FlooringDAL
{
    public class OrderProductionRepository : IOrderRepository
    {
        //private string _filePath = @"C:\Data\Flooring\Orders_";

        public List<Order> LoadOrders(DateTime orderDate)
        {
            List<Order> orders = new List<Order>();

            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = "Server=localhost;Database=FlooringMastery;Trusted_Connection=true";
                connection.Open();
                SqlCommand command = new SqlCommand("select * from [Order] o join Product p on o.ProductType = p.ProductType join Tax t on o.StateCode = t.StateCode where OrderDate = @Date", connection);
                command.Parameters.Add(new SqlParameter("Date", orderDate));
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Order newOrder = new Order();
                        newOrder.OrderNumber = int.Parse(reader[0].ToString());
                        newOrder.CustomerName = reader[1].ToString();
                        newOrder.State = reader[2].ToString();
                        newOrder.TaxRate = decimal.Parse(reader[11].ToString());
                        newOrder.ProductType = reader[3].ToString();
                        newOrder.Area = decimal.Parse(reader[4].ToString());
                        newOrder.CostPerSquareFoot = decimal.Parse(reader[7].ToString());
                        newOrder.LaborCostPerSquareFoot = decimal.Parse(reader[8].ToString());
                        newOrder.MaterialCost = (decimal.Parse(reader[7].ToString()) * decimal.Parse(reader[4].ToString()));
                        newOrder.LaborCost = (decimal.Parse(reader[8].ToString()) * decimal.Parse(reader[4].ToString()));
                        newOrder.Tax = (newOrder.MaterialCost + newOrder.LaborCost) * newOrder.TaxRate / 100;
                        newOrder.Total = newOrder.Tax + newOrder.MaterialCost + newOrder.LaborCost;
                        newOrder.OrderDate = DateTime.Parse(reader[5].ToString());

                        orders.Add(newOrder);
                    }
                }
                connection.Close();
                connection.Dispose();
                return orders;
            }
            
        }

        public void SaveOrder(Order order)
        {
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = "Server=localhost;Database=FlooringMastery;Trusted_Connection=true";
                connection.Open();
                SqlCommand insertCommand = new SqlCommand("insert into [Order] (CustomerName, StateCode, ProductType, Area, OrderDate) values (@0, @1, @2, @3, @4)", connection);
                insertCommand.Parameters.Add(new SqlParameter("0", order.CustomerName));
                insertCommand.Parameters.Add(new SqlParameter("1", order.State));
                insertCommand.Parameters.Add(new SqlParameter("2", order.ProductType));
                insertCommand.Parameters.Add(new SqlParameter("3", order.Area));
                insertCommand.Parameters.Add(new SqlParameter("4", order.OrderDate.ToString("yyyy-MM-dd")));
                insertCommand.ExecuteNonQuery();

                connection.Close();
                connection.Dispose();
            }
        }
        public void UpdateList(Order order)
        {
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = "Server=localhost;Database=FlooringMastery;Trusted_Connection=true";
                connection.Open();
                SqlCommand updateCommand = new SqlCommand("update [Order] set CustomerName = @0, StateCode = @1, ProductType = @2, Area = @3 where ID = @4", connection);
                updateCommand.Parameters.Add(new SqlParameter("0", order.CustomerName));
                updateCommand.Parameters.Add(new SqlParameter("1", order.State));
                updateCommand.Parameters.Add(new SqlParameter("2", order.ProductType));
                updateCommand.Parameters.Add(new SqlParameter("3", order.Area));
                updateCommand.Parameters.Add(new SqlParameter("4", order.OrderNumber));
                updateCommand.ExecuteNonQuery();

                connection.Close();
                connection.Dispose();
            }
        }
        public void Delete(Order order)
        {
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = "Server=localhost;Database=FlooringMastery;Trusted_Connection=true";
                connection.Open();
                SqlCommand deleteCommand = new SqlCommand("delete from [Order] where ID = @0", connection);
                deleteCommand.Parameters.Add(new SqlParameter("0", order.OrderNumber));
                deleteCommand.ExecuteNonQuery();

                connection.Close();
                connection.Dispose();
            }
        }
    }
}

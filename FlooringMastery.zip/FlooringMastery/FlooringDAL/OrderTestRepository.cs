﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlooringModels;
using FlooringModels.Interfaces;

namespace FlooringDAL
{
    public class OrderTestRepository : IOrderRepository
    {
        private static Order _order = new Order
        {
            OrderNumber = 1,
            OrderDate = new DateTime(2019, 09, 16),
            CustomerName = "John Doe",
            State = "OH",
            TaxRate = 6.25M,
            ProductType = "Wood",
            Area = 500.00M,
            CostPerSquareFoot = 5.15M,
            LaborCostPerSquareFoot = 4.75M,
            MaterialCost = 2575.00M,
            LaborCost = 2375.00M,
            Tax = 309.38M,
            Total = 5259.38M,
        };
        private static List<Order> _orders = new List<Order>()
        {
            (_order),
        };

        public List<Order> LoadOrders(DateTime orderDate)
        {
            if (orderDate == _order.OrderDate)
            {
                return _orders;
            }
            else
            {
                return new List<Order>();
            }
        }

        public void SaveOrder(Order order)
        {
            _order = order;
        }
        public void UpdateList(Order order)
        {
            _order = order;
        }
        public void Delete(Order order)
        {
            _order = order;

        }
    }
}

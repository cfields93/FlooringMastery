﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlooringModels;

namespace FlooringMastery
{
    public class ConsoleIO
    {
        public static void ShowOrderDetails(Order order)
        {
            Console.WriteLine("******************************************************************");
            Console.WriteLine($"{order.OrderNumber} | {order.OrderDate.ToString("MM/dd/yyyy")}");
            Console.WriteLine($"{order.CustomerName}");
            Console.WriteLine($"{order.State}");
            Console.WriteLine($"Product: {order.ProductType}");
            Console.WriteLine("Materials: $" + (Math.Round(order.MaterialCost,2)));
            Console.WriteLine("Labor: $" + (Math.Round(order.LaborCost,2)));
            Console.WriteLine("Tax: $" + (Math.Round(order.Tax,2)));
            Console.WriteLine("Total: $" + (Math.Round(order.Total,2)));
            Console.WriteLine("*******************************************************************");
            Console.WriteLine();
        }
    }
}

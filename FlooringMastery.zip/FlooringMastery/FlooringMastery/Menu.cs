﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlooringMastery.Workflows;

namespace FlooringMastery
{
    public class Menu
    {
        public static void Start()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine(@"
************************************************************************************* 
* Flooring Program 
* 
* 1. Display Orders 
* 2. Add an Order 
* 3. Edit an Order 
* 4. Remove an Order 
* 5. Quit 
* 
*************************************************************************************");
                Console.Write("\nEnter a selection: ");
                string input = Console.ReadLine();
                switch(input)
                {
                    case "1":
                        DisplayWorkflow displayFlow = new DisplayWorkflow();
                        displayFlow.Display();
                        break;
                    case "2":
                        AddWorkflow addFlow = new AddWorkflow();
                        addFlow.Add();
                        break;
                    case "3":
                        EditWorkflow editFlow = new EditWorkflow();
                        editFlow.Update();
                        break;
                    case "4":
                        RemoveWorkflow removeFlow = new RemoveWorkflow();
                        removeFlow.Remove();
                        break;
                    case "5":
                        return;
                }
            }
        }
    }
}

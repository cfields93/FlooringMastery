﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlooringBLL.OrderRules;
using FlooringBLL;
using FlooringDAL;
using FlooringModels.Responses;
using FlooringModels;
using FlooringModels.Interfaces;

namespace FlooringMastery.Workflows
{
    public class EditWorkflow
    {
        OrderManager manager = OrderManagerFactory.Create();
        EditRules edit = new EditRules();

        public void Update()
        {
            DateTime date;
            int oNumber;
            decimal newArea = 0;
            string newProduct;
            ProductRepository pRepo = new ProductRepository();
            List<Product> products = pRepo.LoadProducts();
            Order order = new Order();


            Console.Write("Enter the date in which to search for an order (MM/DD/YYYY): ");
            while (!DateTime.TryParse(Console.ReadLine(), out date))
            {
                Console.WriteLine("That is not a valid date format. Please try again.");
            }
            Console.Write("Please enter the order number you wish to edit: ");
            while (!int.TryParse(Console.ReadLine(), out oNumber))
            {
                Console.WriteLine("That is not a valid number. Please try again.");
            }
            OrderLookupResponse response = manager.Lookup(date, oNumber);

            if (response.Success)
            {

                ConsoleIO.ShowOrderDetails(response.Order);
                Console.Write($"Enter Customer Name({response.Order.CustomerName}): ");
                string newName = Console.ReadLine();
                if(newName == "")
                {
                    newName = response.Order.CustomerName;
                }

                Console.Write($"Enter State ({response.Order.State}): ");
                string newState = Console.ReadLine().ToUpper();
                if(newState == "")
                {
                    newState = response.Order.State;
                }

                Console.WriteLine($"Enter Product Type({response.Order.ProductType}): ");
                foreach (var p in products)
                {
                    Console.Write(p.ProductType + " | ");
                }
                newProduct = Console.ReadLine();
                if(newProduct == "")
                {
                    newProduct = response.Order.ProductType;
                }
                else
                {
                    newProduct = char.ToUpper(newProduct[0]) + newProduct.Substring(1);
                }

                Console.Write("Enter Area(" + (Math.Round(response.Order.Area,2)) + "): ");
                string input = Console.ReadLine();
                
                if (input != "")
                {
                    while (true)
                    {
                        while (!decimal.TryParse(input, out newArea))
                        {
                            Console.WriteLine("That is not a valid number. Please try again.");
                        }
                        if(newArea < 100)
                        {
                            Console.WriteLine("The minimum order is 100 sq. ft. Please try again.");
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                else
                {
                    newArea = response.Order.Area;
                }
                if (response.Order.ProductType == newProduct && response.Order.Area == newArea && response.Order.State == newState)
                {
                    OrderEditResponse editResponse1 = edit.Edit(response.Order);
                    if (editResponse1.Success)
                    {
                        ConsoleIO.ShowOrderDetails(response.Order);
                        Console.Write("Would you like to make the changes this order? (Y/N) ");
                        char change;
                        while (!char.TryParse(Console.ReadLine().ToUpper(), out change))
                        {
                            Console.WriteLine("Please enter a valid response. Try again.");
                        }
                        if (change == 'Y')
                        {
                            List<Order> orders = manager.RetrieveAll(date);
                            foreach (var o in orders)
                            {
                                if (o.OrderNumber == response.Order.OrderNumber)
                                {
                                    o.Equals(response.Order);
                                }
                            }
                            manager.Update(response.Order);
                            Console.WriteLine("Order updated!");
                        }
                    }
                    else
                    {
                        Console.WriteLine("An error occured:");
                        Console.WriteLine(editResponse1.Message);
                    }
                }
                order = manager.Compile(date, newName, newState, newProduct, newArea);
                order.OrderNumber = response.Order.OrderNumber;
                OrderEditResponse editResponse = edit.Edit(order);
                if(editResponse.Success)
                {
                    ConsoleIO.ShowOrderDetails(order);
                    Console.Write("Would you like to make the changes this order? (Y/N) ");
                    char change;
                    while (!char.TryParse(Console.ReadLine().ToUpper(), out change))
                    {
                        Console.WriteLine("Please enter a valid response. Try again.");
                    }
                    if (change == 'Y')
                    {
                        List<Order> orders = manager.RetrieveAll(date);
                        foreach(var o in orders)
                        {
                            if(o.OrderNumber == order.OrderNumber)
                            {
                                o.Equals(order);
                            }
                        }
                        manager.Update(order);
                        Console.WriteLine("Order updated!");
                    }
                }
                else
                {
                    Console.WriteLine("An error occured:");
                    Console.WriteLine(editResponse.Message);
                }
            }
            else
            {
                Console.WriteLine("An error occured:");
                Console.WriteLine(response.Message);
            }
            Console.WriteLine("Returning to menu. Press any key to continue...");
            Console.ReadKey();
        }
    }
}

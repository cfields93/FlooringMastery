﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlooringBLL.OrderRules;
using FlooringBLL;
using FlooringDAL;
using FlooringModels.Responses;
using FlooringModels;
using FlooringModels.Interfaces;

namespace FlooringMastery.Workflows
{
    public class AddWorkflow
    {
        public void Add()
        {
            OrderManager manager = OrderManagerFactory.Create();
            ProductRepository pRepo = new ProductRepository();
            List<Product> products = pRepo.LoadProducts();
            AddRules add = new AddRules();

            decimal area;

            Console.Clear();
            Console.Write("Order Date (MM/DD/YYYY): ");
            DateTime date;
            while (true)
            {
                while (!DateTime.TryParse(Console.ReadLine(), out date))
                {
                    Console.WriteLine("Invalid date format. Please try again.");
                }
                if(date < DateTime.Today)
                {
                    Console.WriteLine("Order Date cannot be in the past. Try again.");
                }
                else
                {
                    break;
                }
            }
            string customerName;
            while (true)
            {
                Console.Write("Customer Name:  ");
                customerName = Console.ReadLine();
                if(customerName != "")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("A customer name is required.");
                }
            }
            string state;
            Console.Write("State Code:  ");
            while (true)
            {
                state = Console.ReadLine().ToUpper();
                if (state == "")
                {
                    Console.WriteLine("State cannot be blank. Try again.");
                }
                else
                {
                    break;
                }
            }

            Console.WriteLine("Enter a product from below:");
            foreach (var p in products)
            {
                Console.Write(p.ProductType +" | ");
            }
            string productType;
            while (true)
            {
                productType = Console.ReadLine();
                if (productType == "")
                {
                    Console.WriteLine("Product Type cannot be blank. Try again.");
                }
                else
                {
                    productType = char.ToUpper(productType[0]) + productType.Substring(1);
                    break;
                }
            }
            Console.Write("Area:  ");
            while (true)
            {
                while (!decimal.TryParse(Console.ReadLine(), out area))
                {
                    Console.WriteLine("That is not a valid number. Try again");
                }
                if(area < 100)
                {
                    Console.WriteLine("The minimum order is 100 sq. ft. Please try again.");
                }
                else
                {
                    break;
                }
            }

            OrderAddResponse response = add.Add(state, productType, date, customerName, area);
            if (response.Success)
            {
                Order order = manager.Compile(date, customerName, state, productType, area);
                order = manager.OrderNumber(order);
                ConsoleIO.ShowOrderDetails(order);
                Console.Write("Would you like to place this order? (Y/N) ");
                char place;
                while(!char.TryParse(Console.ReadLine().ToUpper(), out place))
                {
                    Console.WriteLine("Please enter a valid response. Try again.");
                }
                if (place == 'Y')
                {
                    manager.Create(order);
                    Console.WriteLine("Order placed!");
                }
                

            }
            else
            {
                Console.WriteLine("An error occured:");
                Console.WriteLine(response.Message);
            }
            Console.WriteLine("Returning to menu. Press any key to continue...");
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlooringBLL.OrderRules;
using FlooringBLL;
using FlooringDAL;
using FlooringModels.Responses;
using FlooringModels;
using FlooringModels.Interfaces;

namespace FlooringMastery.Workflows
{
    public class DisplayWorkflow
    {
        public void Display()
        {

            OrderManager manager = OrderManagerFactory.Create();
            Console.Write("Enter the date you would like to show the orders for (MM/DD/YYYY): ");
            DateTime date;
            while(!DateTime.TryParse(Console.ReadLine(),out date))
            {
                Console.WriteLine("That is not a valid date format. Please try again.");
            }

            List<Order> orders = manager.RetrieveAll(date);
            if (orders.Count != 0)
            {
                foreach (var o in orders)
                {
                    ConsoleIO.ShowOrderDetails(o);
                }
            }
            else
            {
                Console.WriteLine("There are no orders for that date.");
            }

            Console.WriteLine("Returning to menu. Press any key to continue...");
            Console.ReadKey();
        }
    }
}

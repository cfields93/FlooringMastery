﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlooringBLL.OrderRules;
using FlooringBLL;
using FlooringModels.Responses;
using FlooringModels.Interfaces;

namespace FlooringMastery.Workflows
{
    class RemoveWorkflow
    {
        OrderManager manager = OrderManagerFactory.Create();
        public void Remove()
        {
            DateTime date;
            int oNumber;

            Console.Write("Enter the date in which to search for an order (MM/DD/YYYY): ");
            while (!DateTime.TryParse(Console.ReadLine(), out date))
            {
                Console.WriteLine("That is not a valid date format. Please try again.");
            }
            Console.Write("Please enter the order number you wish to remove: ");
            while (!int.TryParse(Console.ReadLine(), out oNumber))
            {
                Console.WriteLine("That is not a valid number. Please try again.");
            }
            OrderLookupResponse response = manager.Lookup(date, oNumber);
            if(response.Success)
            {
                ConsoleIO.ShowOrderDetails(response.Order);
                Console.Write("Are you sure you want to remove this order? (Y/N) ");
                char remove;
                while (!char.TryParse(Console.ReadLine().ToUpper(), out remove))
                {
                    Console.WriteLine("Please enter a valid response. Try again.");
                }
                if(remove == 'Y')
                {
                    OrderRemoveResponse removeResponse = manager.Remove(date, oNumber);
                    if(removeResponse.Success)
                    {
                        Console.WriteLine("Order removed successfully.");
                    }
                }
            }
            else
            {
                Console.WriteLine("An error occured: ");
                Console.WriteLine(response.Message);
            }

            Console.WriteLine("Returning to menu. Press any key to continue...");
            Console.ReadKey();
        }
    }
}

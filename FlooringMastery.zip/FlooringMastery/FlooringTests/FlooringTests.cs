﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using FlooringDAL;
using FlooringBLL.OrderRules;
using FlooringBLL;
using FlooringModels.Responses;
using FlooringModels;
using FlooringModels.Interfaces;

namespace FlooringTests
{
    [TestFixture]
    public class FlooringTests
    {
        

        [TestCase("MI", "Concrete", 2019, 12, 31, "john", 500.00, false)] // invalid product
        [TestCase("MN", "Wood", 2019, 12, 31, "john", 500.00, false)] // invalid state
        [TestCase("MI", "Laminate", 2019, 12, 31, "john", 500.00, true)]
        [TestCase("MI", "Laminate", 2019, 12, 31, "Acme, Inc.", 500.00, true)]
        [TestCase("MI", "Laminate", 2019, 12, 31, "Acme/ Inc.", 500.00, false)] // invalid character
        [TestCase("MI", "Laminate", 2019, 12, 31, "Acme+ Inc.", 500.00, false)] // invalid character
        [TestCase("OH", "Carpet", 2019, 12, 31, "smith, john", 500.00, true)]
        [TestCase("OH", "Carpet", 2019, 1, 31, "john", 500.00, false)] // invalid date
        [TestCase("OH", "Carpet", 2019, 12, 31, "", 500.00, false)] // no customer name
        [TestCase("OH", "Carpet", 2019, 12, 31, "john", 50.00, false)] // area less than 100
        public void AddRulesTest(string state, string productType, int Y, int M, int D, string name, decimal area, bool expected)
        {
            DateTime date = new DateTime(Y, M, D);
            AddRules addRules = new AddRules();
            OrderAddResponse actual = addRules.Add(state, productType, date, name, area);

            Assert.AreEqual(expected, actual.Success);
        }

        [TestCase("MN", "Hard Wood", 2019, 12, 31, "john", 500.00, false)] // invalid product and state
        [TestCase("Minnesota", "Vinyl", 2019, 12, 31, "john", 500.00, false)] // invalid product and state format
        [TestCase("OH", "Wood", 2019, 12, 31, "john", 500.00, true)]
        [TestCase("MI", "Vinyl", 2019, 12, 31, "john", 500.00, false)] // invalid product
        [TestCase("MN", "Wood", 2019, 12, 31, "john", 500.00, false)] // invalid state
        [TestCase("MI", "Laminate", 2019, 12, 31, "Acme, Inc.", 500.00, true)]
        [TestCase("PA", "Laminate", 2019, 1, 31, "smith, john", 500.00, true)]
        [TestCase("PA", "Laminate", 2019, 12, 31, "", 500.00, false)] // no customer name
        [TestCase("PA", "Laminate", 2019, 12, 31, "john", 50.00, false)] // area less than 100
        [TestCase("MI", "Laminate", 2019, 12, 31, "Acme/ Inc.", 500.00, false)] // invalid character
        [TestCase("MI", "Laminate", 2019, 12, 31, "Acme+ Inc.", 500.00, false)] // invalid character
        public void EditRulesTest(string state, string productType, int Y, int M, int D, string name, decimal area, bool expected)
        {
            DateTime date = new DateTime(Y, M, D);
            EditRules editRules = new EditRules();
            Order order = new Order();

            order.State = state;
            order.ProductType = productType;
            order.CustomerName = name;
            order.OrderDate = date;
            order.Area = area;

            OrderEditResponse actual = editRules.Edit(order);

            Assert.AreEqual(expected, actual.Success);
        }


        [TestCase(2019, 09, 16, 1, true)]
        [TestCase(2019, 10, 11, 1, false)] // no orders on date
        [TestCase(2019, 09, 16, 2, false)] // no order 2 on that date
        public void LookUpTest(int Y, int M, int D, int orderNumber, bool expected)
        {
            DateTime date = new DateTime(Y, M, D);
            OrderManager manager = new OrderManager(new OrderTestRepository());
            OrderLookupResponse response = manager.Lookup(date, orderNumber);

            Assert.AreEqual(expected, response.Success);
        }

        [TestCase(2018, 08, 12, 0)] // no orders on date
        [TestCase(2019, 09, 16, 1)] 
        public void RetrieveAllTest(int Y, int M, int D, int expected)
        {
            DateTime date = new DateTime(Y, M, D);
            OrderManager manager = new OrderManager(new OrderTestRepository());
            List<Order> orders = manager.RetrieveAll(date);

            Assert.AreEqual(expected, orders.Count);
        }

        [TestCase(2019, 09, 16, 1, true)]
        [TestCase(2019, 09, 16, 2, false)] // no order 2 on date
        [TestCase(2019, 10, 11, 1, false)] // no orders on date
        public void RemoveTest(int Y, int M, int D, int orderNumber, bool expected)
        {
            DateTime date = new DateTime(Y, M, D);
            OrderManager manager = new OrderManager(new OrderTestRepository());
            OrderRemoveResponse response = manager.Remove(date, orderNumber);

            Assert.AreEqual(expected, response.Success);
        }

        [TestCase(2019, 09, 16, "john", "MI", 5.75, "Wood", 500.00, 5.15, 4.75, 2575.00, 2375.00, 284.625, 5234.625, 2)] // 1 order on date already, next order is #2
        [TestCase(2019, 10, 16, "john", "MI", 5.75, "Wood", 500.00, 5.15, 4.75, 2575.00, 2375.00, 284.625, 5234.625, 1)] // no orders on date, order is #1
        public void OrderNumberTest(int Y, int M, int D, string name, string state, decimal taxRate, string product, decimal area, decimal cpsf, decimal lcpsf, decimal mc, decimal lc, decimal tax, decimal total, int expected)
        {
            DateTime date = new DateTime(Y, M, D);
            Order order = new Order();
            order.OrderDate = date;
            order.CustomerName = name;
            order.State = state;
            order.TaxRate = taxRate;
            order.ProductType = product;
            order.Area = area;
            order.CostPerSquareFoot = cpsf;
            order.LaborCostPerSquareFoot = lcpsf;
            order.MaterialCost = mc;
            order.LaborCost = lc;
            order.Tax = tax;
            order.Total = total;
            OrderManager manager = new OrderManager(new OrderTestRepository());
            order = manager.OrderNumber(order);

            Assert.AreEqual(expected, order.OrderNumber);
        }


    }
}

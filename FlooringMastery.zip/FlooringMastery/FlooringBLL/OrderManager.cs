﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlooringModels.Interfaces;
using FlooringModels.Responses;
using FlooringModels;
using FlooringDAL;

namespace FlooringBLL
{
    public class OrderManager
    {
        private IOrderRepository _orderRepo;

        public OrderManager(IOrderRepository orderRepo)
        {
            _orderRepo = orderRepo;
        }

        public OrderLookupResponse Lookup(DateTime date, int orderNumber)
        {
            OrderLookupResponse response = new OrderLookupResponse();

            List<Order> orders = _orderRepo.LoadOrders(date);
            response.Order = orders.FirstOrDefault(o => o.OrderNumber == orderNumber);
            string sDate = date.ToString("MM/dd/yyyy");

            if(response.Order == null)
            {
                response.Success = false;
                response.Message = $"Order number {orderNumber} was not found in {sDate}.";
            }
            else
            {
                response.Success = true;
            }
            return response;
        }
        public List<Order> RetrieveAll(DateTime date)
        {
            List<Order> orders = _orderRepo.LoadOrders(date);
            return orders;
        }
        public void Create(Order order)
        {
            _orderRepo.SaveOrder(order);
        }
        public Order Compile(DateTime date, string customerName, string stateCode, string productType, decimal area)
        { 
            Order order = new Order();
            ProductRepository pRepo = new ProductRepository();
            StateRepository sRepo = new StateRepository();
            List<Product> products = pRepo.LoadProducts();
            List<State> states = sRepo.LoadStates();
            Product product = products.FirstOrDefault(p => p.ProductType == productType);
            State state = states.FirstOrDefault(s => s.StateCode == stateCode);
            
           
                order.OrderDate = date;
            
            if (customerName != "")
            {
                order.CustomerName = customerName;
            }
            if (stateCode != "")
            {
                order.State = stateCode;
            }
            order.TaxRate = state.TaxRate;
            if (productType != "")
            {
                order.ProductType = productType;
            }
            if (area != 0)
            {
                order.Area = area;
            }
            order.CostPerSquareFoot = product.CostPerSquareFoot;
            order.LaborCostPerSquareFoot = product.LaborCostPerSquareFoot;
            order.MaterialCost = (area * product.CostPerSquareFoot);
            order.LaborCost = (area * product.LaborCostPerSquareFoot);
            order.Tax = (order.MaterialCost + order.LaborCost) * (state.TaxRate / 100);
            order.Total = (order.MaterialCost + order.LaborCost + order.Tax);

            return order;
        }
        public OrderRemoveResponse Remove(DateTime date, int orderNumber)
        {
            OrderRemoveResponse response = new OrderRemoveResponse();
            OrderLookupResponse lookup = Lookup(date, orderNumber);
            if(lookup.Success)
            {
                _orderRepo.Delete(lookup.Order);
                //List<Order> orders = _orderRepo.LoadOrders(date);
                //orders.RemoveAll(o => o.OrderNumber == lookup.Order.OrderNumber);
                response.Success = true;
                //_orderRepo.UpdateList(orders);
            }
            else
            {
                response.Success = false;
                response.Message = "Not able to remove account after it was found. Contact IT.";
            }
            return response;
        }
        public void Update(Order order)
        {
            OrderEditResponse response = new OrderEditResponse();
            OrderLookupResponse lookup = Lookup(order.OrderDate, order.OrderNumber);
            if (lookup.Success)
            {
                _orderRepo.UpdateList(order);
                //List<Order> orders = _orderRepo.LoadOrders(date);
                //foreach (var o in orders)
                //{
                //    if(o.OrderNumber == orderNumber)
                //    {
                //        o.CustomerName = customerName;
                //        o.State = state;
                //        o.ProductType = productType;
                //        o.Area = area;
                //    }
                //}
                response.Success = true;
                //_orderRepo.UpdateList(orders);
            }
            else
            {
                response.Success = false;
                response.Message = "Not able to edit account after it was found. Contact IT.";
            }
            
        }
        public Order OrderNumber(Order order)
        {
            List<Order> orders = _orderRepo.LoadOrders(order.OrderDate);
            if (orders.Count != 0)
            {
                var index = orders.OrderByDescending(o => o.OrderNumber).First();
                order.OrderNumber = index.OrderNumber + 1;
                            
            }
            else
            {
                order.OrderNumber = 1;
            }
            return order;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlooringDAL;

namespace FlooringBLL
{
    public class OrderManagerFactory
    {
        public static OrderManager Create()
        {
            string mode = ConfigurationManager.AppSettings["mode"].ToString();

            switch(mode)
            {
                case "test":
                    return new OrderManager(new OrderTestRepository());
                case "prod":
                    return new OrderManager(new OrderProductionRepository());
                default:
                    throw new Exception("Mode value in app config is not valid");
            }
        }
    }
}

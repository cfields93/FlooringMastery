﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlooringModels.Responses;
using FlooringModels.Interfaces;
using FlooringModels;
using FlooringDAL;

namespace FlooringBLL.OrderRules
{
    public class EditRules : IEdit
    {
        StateRepository stateRepo = new StateRepository();
        ProductRepository productRepo = new ProductRepository();
        public OrderEditResponse Edit(Order order)
        {
            OrderEditResponse response = new OrderEditResponse();
            List<Product> products = productRepo.LoadProducts();
            List<State> states = stateRepo.LoadStates();
            string allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789., ";

            if (order.State.Length > 2)
            {
                response.Success = false;
                response.Message = "Please enter a 2 character state code.";
                return response;
            }
            else if (order.State.Length == 2)
            {
                var resultCode = states.FirstOrDefault(s => s.StateCode.Contains(order.State));
                if (resultCode == null)
                {
                    response.Success = false;
                    response.Message = "We are not authorized to sell products in that state.";
                    return response;
                }
            }
            if (order.CustomerName == "")
            {
                response.Success = false;
                response.Message = "Customer Name must be entered to save an order.";
                return response;
            }
            if (order.Area < 100)
            {
                response.Success = false;
                response.Message = "Minimum order is 100sq. ft.";
                return response;
            }
            foreach (var letter in order.CustomerName)
            {
                if (!allowed.Contains(letter))
                {
                    response.Success = false;
                    response.Message = $"The use of {letter} is not allowed in the customer name field.";
                    return response;
                }
            }
            var result = products.FirstOrDefault(p => p.ProductType.Contains(order.ProductType));
            if (result == null)
            {
                response.Success = false;
                response.Message = "We do not have a product by that name in our inventory.";
                return response;
            }

            response.Success = true;
            response.Order = order;
            return response;

        }
    }
}

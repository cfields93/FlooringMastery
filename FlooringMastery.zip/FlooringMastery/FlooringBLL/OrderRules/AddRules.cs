﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlooringModels.Responses;
using FlooringModels.Interfaces;
using FlooringModels;
using FlooringDAL;

namespace FlooringBLL.OrderRules
{
    public class AddRules : IAdd
    {
        StateRepository stateRepo = new StateRepository();
        ProductRepository productRepo = new ProductRepository();
        public OrderAddResponse Add(string state, string productType, DateTime date, string name, decimal area)
        {
            OrderAddResponse response = new OrderAddResponse();
            List<Product> products = productRepo.LoadProducts();
            List<State> states = stateRepo.LoadStates();
            string allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789., ";

            if (state.Length > 2)
            {
                response.Success = false;
                response.Message = "Please enter a 2 character state code.";
                return response;

            }
            else if (state.Length == 2)
            {
                var resultCode = states.FirstOrDefault(s => s.StateCode.Contains(state));
                if (resultCode == null)
                {
                    response.Success = false;
                    response.Message = "We are not authorized to sell products in that state.";
                    return response;
                }
            }
            foreach (var letter in name)
            {
                if (!allowed.Contains(letter))
                {
                    response.Success = false;
                    response.Message = $"The use of {letter} is not allowed in the customer name field.";
                    return response;
                }
            }
            if (date < DateTime.Today)
            {
                response.Success = false;
                response.Message = "Order date cannot be in the past.";
                return response;
            }
            if(name == "")
            {
                response.Success = false;
                response.Message = "Customer Name must be entered to save an order.";
                return response;
            }
            if(area < 100)
            {
                response.Success = false;
                response.Message = "Minimum order is 100sq. ft.";
                return response;
            }
            var result = products.FirstOrDefault(p => p.ProductType.Contains(productType));
            if (result == null)
            {
                response.Success = false;
                response.Message = "We do not have a product by that name in our inventory.";
                return response;
            }

            response.Success = true;
            return response;

        }
    }
    
}
